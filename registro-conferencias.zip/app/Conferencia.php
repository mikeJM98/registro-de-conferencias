<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conferencia extends Model
{
    //
}
