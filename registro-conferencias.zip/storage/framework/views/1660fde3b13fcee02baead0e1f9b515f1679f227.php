<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Consulta Reniec</title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/axios.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
    
<body>
    <div class="container conten-fluit" id="app">
        <div class="row mt-5">
            <component></component>           
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp72\htdocs\registro-conferencias\resources\views/welcome.blade.php ENDPATH**/ ?>