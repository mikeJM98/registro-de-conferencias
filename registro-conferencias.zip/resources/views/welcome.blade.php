<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Consulta Reniec</title>
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <script src="{{ asset('js/axios.js') }}" defer></script>
<script src="{{ asset('js/app.js') }}" defer></script>
</head>
    
<body>
    <div class="container conten-fluit" id="app">
        <div class="row mt-5">
            <component></component>           
        </div>
    </div>
</body>
</html>